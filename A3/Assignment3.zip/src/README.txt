README
Group #29
Christopher Friesen cmf2536
Joseph Le jsl2449
Main method is within A3Driver.java
GIT url: https://github.com/CFreezz/Assignment3.git



